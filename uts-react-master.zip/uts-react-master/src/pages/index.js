import LuasLingkaran from './LuasLingkaran'
import Splash from './splash'
import Home from './home'
import Grade from './Grade'
import LuasSegitiga from './LuasSegitiga'
import LuasPersegi from'./LuasPersegi'


export{Home, Splash, LuasLingkaran, LuasPersegi, LuasSegitiga, Grade} 